const UserModal = require("./User");
const LikesModal = require("./Likes")

module.exports = {
    UserModal,
    LikesModal
}
